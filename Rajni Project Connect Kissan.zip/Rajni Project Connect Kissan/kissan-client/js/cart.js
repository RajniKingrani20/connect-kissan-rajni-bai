// var cartBtn = document.querySelectorAll(".item");

// if (document.readyState == "loading") {
//   document.addEventListener("DOMContentLoaded", function () {
//     console.log(cartBtn);
//   });
// } else {
//   console.log(cartBtn);
// }

// const pr = document.getElementById("product");
// pr.addEventListener("click", function (e) {
//   console.log(e.target);
//   console.log(e);
// });
// // for (let index = 0; index < cartBtn.length; index++) {
// //   cartBtn[index].addEventListener("click", (e) => {
// //     console.log(e.target);
// //     console.log("kjfdg");
// //   });
// // }
